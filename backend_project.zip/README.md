# Dashboard Backend

## Overview
This is a Node.js-based backend for a dashboard application with:
- SQLite database for persistent storage.
- JWT authentication for secure access.
- API endpoints to fetch and update dashboard data.

## Setup

### Prerequisites
- Node.js installed on your system.

### Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/lexxy2422/dashboard-backend.git
   cd dashboard-backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the server:
   ```bash
   npm start
   ```

4. The server will run at `http://localhost:5000`.

### API Endpoints
#### `POST /login`
**Request**:
```json
{
  "username": "admin",
  "password": "password"
}
```
**Response**:
```json
{
  "token": "your-jwt-token"
}
```

#### `GET /dashboard`
**Headers**:
```json
Authorization: Bearer your-jwt-token
```
**Response**:
```json
{
  "revenue": 50000,
  "sales": 4500
}
```

#### `PUT /dashboard`
**Headers**:
```json
Authorization: Bearer your-jwt-token
```
**Request**:
```json
{
  "revenue": 100000,
  "sales": 9000
}
```
**Response**:
```json
{
  "revenue": 100000,
  "sales": 9000
}
```

## Deployment
- Deploy the backend using platforms like Render or Heroku.
- Ensure you set the `SECRET_KEY` environment variable for JWT.

## License
This project is licensed under the MIT License.